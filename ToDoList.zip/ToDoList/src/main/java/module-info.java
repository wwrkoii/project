module com.example.todolist {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;

    requires org.xerial.sqlitejdbc;


    opens com.example.todolist to javafx.fxml;
    exports com.example.todolist;
    exports com.example.todolist.db;
    exports com.example.todolist.model;
}