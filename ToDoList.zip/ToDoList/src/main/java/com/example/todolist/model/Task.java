package com.example.todolist.model;

public class Task {
    private final Integer id;
    private final String name;
    private final String description;
    private  final String tag;
    private  final String login;


    public Task(Integer id, String name, String tag, String login, String description) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.tag = tag;
        this.login = login;

    }

    public Integer getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public String getTag() {
        return tag;
    }

    public String getLogin() {
        return login;
    }
}