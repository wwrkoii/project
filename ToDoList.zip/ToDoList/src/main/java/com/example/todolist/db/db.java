package com.example.todolist.db;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import com.example.todolist.model.Task;

import java.sql.*;

public class db {
    private static String dbURL = "jdbc:sqlite:test.db";

    public static void createNewDatabase() {
        try {
            Connection conn = DriverManager.getConnection(dbURL);
            if (conn != null) {
                DatabaseMetaData meta = conn.getMetaData();
                System.out.printf("The driver name is %s\n", meta.getDriverName());
                System.out.println("A database has been created");

            }
        } catch (SQLException e) {
            System.out.println(e.getMessage());;
        }
    }

    public static void createNewTable() {
        String sql = "CREATE TABLE IF NOT EXISTS Users" +
                "(Id INTEGER PRIMARY KEY, " +
                "Login TEXT NOT NULL, " +
                "PASSWORD TEXT NOT NULL);";
        try (Connection conn = DriverManager.getConnection(dbURL);
             Statement stmt =conn.createStatement()) {
            stmt.execute(sql);
        } catch (SQLException e) {
            System.out.println(e.getMessage());;
        }
    }

    public static void createDefaultUser() {
        String sql = "INSERT INTO Users(Login,Password) VALUES ('user1','pass1');";
        try (Connection conn = DriverManager.getConnection(dbURL);
             Statement stmt =conn.createStatement()) {
            stmt.execute(sql);
        } catch (SQLException e) {
            System.out.println(e.getMessage());;
        }
    }

    public static boolean CheakCredential(String login,String password) {
        String sql="SELECT Login,password FROM Users where Login=? and password=?;";
        boolean isTrue = false;
        try (Connection conn = DriverManager.getConnection(dbURL);
             PreparedStatement pstmt =conn.prepareStatement(sql)) {
            pstmt.setString(1,login);
            pstmt.setString(2,password);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                isTrue = true;
            } else isTrue = false;

        }
        catch (SQLException e) {
            System.out.println(e.getMessage());;
        }
        return isTrue;

    }

    public static void registration(String login, String password) {
        String sql = "INSERT INTO Users(Login,Password) VALUES (?,?);";
        try (Connection conn = DriverManager.getConnection(dbURL);
             PreparedStatement pstmt =conn.prepareStatement(sql)) {
            pstmt.setString(1, login);
            pstmt.setString(2, password);
            pstmt.execute();
        }
        catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public static void createTaskTable() {
        String sql = "CREATE TABLE IF NOT EXISTS Tasks" +
                "(Id INTEGER PRIMARY KEY," +
                "Name TEXT NOT NULL," +
                "Tag TEXT," +
                "Login TEXT," +
                "Description TEXT);";
        try (Connection conn = DriverManager.getConnection(dbURL);
             Statement stmt = conn.createStatement()){
            stmt.execute(sql);
            System.out.println("Table Tasks created");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public static void createTask(String name, String tag, String login, String description) {
        String sql = "INSERT INTO Tasks(Name, Tag, Login, Description) VALUES (?,?,?, ?);";
        try (Connection conn = DriverManager.getConnection(dbURL);
             PreparedStatement pstmt =conn.prepareStatement(sql)) {
            pstmt.setString(1, name);
            pstmt.setString(2, tag);
            pstmt.setString(3, login);
            pstmt.setString(4, description);

            pstmt.execute();
            System.out.printf("task \"%s\" created\n", name);
        }
        catch (SQLException e) {
            System.out.println(e.getMessage());
        }

    }


    public static ObservableList<Task> selectTasks(String login) {
        String sql = "SELECT Id,Name,Tag, Description FROM Tasks WHERE Login=?;";
        ObservableList<Task> tasks = FXCollections.observableArrayList();
        try (Connection conn = DriverManager.getConnection(dbURL);
             PreparedStatement pstmt =conn.prepareStatement(sql)) {
            pstmt.setString(1,login);
            ResultSet rs = pstmt.executeQuery();
            //tasks.clear();
            while (rs.next()) {
                //System.out.println( rs.getString("Name"));
                tasks.add(new Task(

                        rs.getInt("Id"),
                        rs.getString("Name"),
                        rs.getString("Tag"),
                        login,
                        rs.getString("Description")));
            }
            System.out.printf("task selected\n");
        }
        catch (SQLException e) {
            System.out.println(e.getMessage());
        }
        return tasks;

    }






}