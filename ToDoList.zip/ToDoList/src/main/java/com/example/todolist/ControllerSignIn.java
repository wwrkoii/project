package com.example.todolist;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import static com.example.todolist.db.db.*;

public class ControllerSignIn {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TextField loginField;

    @FXML
    private PasswordField passField;

    @FXML
    private Button regBtn;

    @FXML
    private Button signBtn;

    @FXML
    void onRegBtn(ActionEvent event) {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/com/example/todolist/registration.fxml"));
        try {
            loader.load();
        } catch (IOException e) {
            e.printStackTrace();
        }
        Parent root = loader.getRoot();
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.showAndWait();
        stage = (Stage) regBtn.getScene().getWindow();
        stage.close();

    }

    @FXML
    void onSignBtn(ActionEvent event) {
        String login = loginField.getText();
        String pass = passField.getText();
        if (CheakCredential(login, pass)) {
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("/com/example/todolist/task.fxml"));
            try {
                loader.load();
            } catch (IOException e) {
                e.printStackTrace();
            }
            Parent root = loader.getRoot();
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.show();
            stage = (Stage) regBtn.getScene().getWindow();
            stage.close();
        }


    }

    @FXML
    void initialize() {
        assert loginField != null : "fx:id=\"loginField\" was not injected: check your FXML file 'auth.fxml'.";
        assert passField != null : "fx:id=\"passField\" was not injected: check your FXML file 'auth.fxml'.";
        assert regBtn != null : "fx:id=\"regBtn\" was not injected: check your FXML file 'auth.fxml'.";
        assert signBtn != null : "fx:id=\"signBtn\" was not injected: check your FXML file 'auth.fxml'.";

    }

}
