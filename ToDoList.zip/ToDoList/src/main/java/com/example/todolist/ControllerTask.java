package com.example.todolist;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import static com.example.todolist.db.db.*;
import com.example.todolist.model.Task;
import javafx.scene.control.cell.PropertyValueFactory;


public class ControllerTask {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TableColumn<Task, String> descrc;

    @FXML
    private TextField descrp;

    @FXML
    private Button filter;

    @FXML
    private TableColumn<Task, String> logc;

    @FXML
    private TextField logf;

    @FXML
    private TableColumn<Task, String> namec;

    @FXML
    private TextField namef;

    @FXML
    private TableColumn<Task, String> tagc;

    @FXML
    private TextField tagf;

    @FXML
    private TextField tagfilter;


    @FXML
    private TableView<Task> table;

    @FXML
    void onAdd(ActionEvent event) {
        String name = namef.getText();
        String description = descrp.getText();
        String tag = tagf.getText();
        //createTaskTable();
        createTask(name, tag, "u2", description);
        setTableview();
    }

    public void setTableview() {
        ObservableList<Task> tasks;
        tasks = selectTasks("u2");
        namec.setCellValueFactory(new PropertyValueFactory<>("name"));
        tagc.setCellValueFactory(new PropertyValueFactory<>("tag"));
        descrc.setCellValueFactory(new PropertyValueFactory<>("description"));
        table.setItems(tasks);
    }




    @FXML
    void onFilter(ActionEvent event) {

    }

    @FXML
    void initialize() {
        assert descrc != null : "fx:id=\"descrc\" was not injected: check your FXML file 'task.fxml'.";
        assert descrp != null : "fx:id=\"descrp\" was not injected: check your FXML file 'task.fxml'.";
        assert filter != null : "fx:id=\"filter\" was not injected: check your FXML file 'task.fxml'.";
        assert logc != null : "fx:id=\"logc\" was not injected: check your FXML file 'task.fxml'.";
        assert logf != null : "fx:id=\"logf\" was not injected: check your FXML file 'task.fxml'.";
        assert namec != null : "fx:id=\"namec\" was not injected: check your FXML file 'task.fxml'.";
        assert namef != null : "fx:id=\"namef\" was not injected: check your FXML file 'task.fxml'.";
        assert tagc != null : "fx:id=\"tagc\" was not injected: check your FXML file 'task.fxml'.";
        assert tagf != null : "fx:id=\"tagf\" was not injected: check your FXML file 'task.fxml'.";
        assert tagfilter != null : "fx:id=\"tagfilter\" was not injected: check your FXML file 'task.fxml'.";
        setTableview();

    }

}
