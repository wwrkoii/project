package com.example.todolist;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import static com.example.todolist.db.db.*;

import java.io.IOException;
import java.util.Objects;

public class ControllerRegistration {

    @FXML
    private TextField LoginReg;

    @FXML
    private PasswordField PassReg1;

    @FXML
    private PasswordField PassReg2;

    @FXML
    private Button btnExit;

    @FXML
    private Button regbtn;


    @FXML
    void onReg(ActionEvent event) {
        String login = LoginReg.getText();
        String pass1 = PassReg1.getText();
        String pass2 = PassReg2.getText();
        if (Objects.equals(pass1, pass2)) {
            registration(login, pass1);
        }
        else {
            System.out.println("undifferent pass");
        }

    }

    @FXML
    void onExit(ActionEvent event) {
        Stage stage = new Stage();
        stage = (Stage) btnExit.getScene().getWindow();
        stage.close();


    }

}
